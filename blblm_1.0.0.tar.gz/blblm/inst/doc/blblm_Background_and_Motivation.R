## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup, warning = FALSE, message = FALSE----------------------------------
library(blblm)
library(tidyverse)   # for analysis 
library(knitr)       # for pretty tables

data(iris)

## ----sampling-----------------------------------------------------------------
set.seed(1020)

m = 10             # Break data up into m subsample
n = nrow(iris)/m   #   with each s containing n samples 

a_sample = iris[sample(nrow(iris), n, replace = TRUE),] 
kable(
  head(a_sample)
)                               # Preview of one subsample

kable(
  nrow(a_sample),               #  with n samples
  col.names = "Subsample Size") 

## ----oldci--------------------------------------------------------------------

# Find the dataset correlation bet petal features
cor <- round(with(iris, cor(Petal.Width, Petal.Length)),4)

# Return the confidence interval bounds for our single sample of irises
ci <-  with(iris, cor.test(Petal.Width, Petal.Length)$conf.int) 


## ----bootstrapci, cache = TRUE------------------------------------------------
library(rsample) # for bootstrapping 

# Create 10,000 resamples of the iris data
boots <- bootstraps(iris, times = 10)

# Calculate the error for bootstrapped CI
se <- boots %>%        # From our list of 10,000 samples
  pull(splits) %>%     #  With each sampling
  map_dbl(
    ~ {
      train_data <- analysis(.)
      with(train_data, cor(Petal.Width, Petal.Length))   # Collect the correlation
    }
  ) %>%
  sd()                                                   #  and report the error 

# Calculate the upper and lower bounds
cib <- with(iris, cor(Petal.Width, Petal.Length)) + 1.96 * c(-1, 1) * se

