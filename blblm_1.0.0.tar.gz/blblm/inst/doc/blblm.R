## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup, warning = FALSE, message = FALSE----------------------------------
library(blblm)
library(tidyverse)   # for analysis 
library(knitr)       # for pretty tables

data(iris)
set.seed(1020)

## -----------------------------------------------------------------------------
# Create a model with m subsets, each bootstrapped B times. 
fit <- blblm(Sepal.Length ~ Petal.Width + Petal.Length, data = iris, m = 10, B = 15)

# Works with interactions as well 
blblm(Sepal.Length ~ Petal.Width + Petal.Length + Petal.Width * Petal.Length, 
        data = iris, m = 10, B = 15)


## -----------------------------------------------------------------------------
# Print the formula model
print(fit)


## -----------------------------------------------------------------------------
# Return sigma without CI
sigma(fit)

# return sigma with CI
sigma(fit, confidence =TRUE)

# return sigma with 90% CI
sigma(fit, confidence =TRUE, level = .90)


## -----------------------------------------------------------------------------
coef(fit)


## -----------------------------------------------------------------------------

# Coefficient Confidence Interal, default alpha = 0.05
confint(fit)

# Coefficient Confidence Interal, alpha = 0.10
confint(fit, level = 0.90)

# Return only first and second coef CI's
confint(fit, parm = 1) # Just the Petal.Width

## -----------------------------------------------------------------------------

# Single Value prediction
predict(fit, iris[4,])

# Take a random sampling  of ten points from the iris data
X <- iris[sample(seq_len(150), 10),]
head(X)

# Fit the values to our model
predict(fit, X)
plot(predict(fit,X), X[,1]) # Plotted values

# Fit them with a confidence interval 
predict(fit, X, confidence = TRUE)


