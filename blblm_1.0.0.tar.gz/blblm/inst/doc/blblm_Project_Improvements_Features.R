## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## -----------------------------------------------------------------------------
set.seed(2240)
par(mfrow=c(1,2))

# Break up iris data into 10 subsets, assign mults
freqs <- rmultinom(1, nrow(iris)/10, rep(1, nrow(iris)))
plot(freqs)


freqs2 <- rmultinom(1, nrow(iris)/2, rep(1, nrow(iris)))
plot(freqs2)


