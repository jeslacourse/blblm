## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(blblm)

## ----warning=FALSE------------------------------------------------------------
# Create a model with m subsets, each bootstrapped B times. 
data(iris)

# Gaussian Case
blbglm(Sepal.Width~ Species, #numeric by factor 
              data = iris, m = 2, B = 100)

# Binomial Case
bi_iris <- iris[1:100,] # binomial
fit <- blbglm(formula = Species ~ Sepal.Width+Sepal.Length, 
              data = bi_iris, family ="binomial", m = 2, B = 100)

#
# Notes: Convergence errors gave this dataset some pretty wild coefficients
#         and sigmas. Per Randy, these errors are suppress, as the error 
#         handling is in place in glm1(). In short, this wasn't the best 
#         dataset to test with, but it shows the project's functionality.


## -----------------------------------------------------------------------------
# Print the formula model
print(fit)


## -----------------------------------------------------------------------------

# Return sigma without CI
sigma(fit)

# return sigma with CI
sigma(fit, confidence =TRUE)

# return sigma with 90% CI
sigma(fit, confidence =TRUE, level = .90)


## -----------------------------------------------------------------------------
coef(fit)


## -----------------------------------------------------------------------------
# Coefficient Confidence Interal, default alpha = 0.05
confint(fit)

# Coefficient Confidence Interal, alpha = 0.10
confint(fit, level = 0.90)


## -----------------------------------------------------------------------------

# Single Value prediction
predict(fit, iris[4,])

# Take a random sampling  of ten points from the iris data
X <- iris[sample(seq_len(150), 10),]
head(X)

# Fit the values to our model
predict(fit, X)

# Fit them with a confidence interval 
predict(fit, X, confidence = TRUE)



