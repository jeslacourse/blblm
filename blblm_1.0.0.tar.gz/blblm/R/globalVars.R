
# Acknowledgement of  global variables in pipelines
utils::globalVariables(c("."))